import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const fail = (message) => { throw new Error(message); };
const esc = (s) => String(s).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&apos;");
const csvRows = (input) => {
  const rows = []; let row = []; let value = ""; let quoted = false;
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    if (quoted && char === '"' && input[i + 1] === '"') { value += '"'; i++; }
    else if (char === '"') quoted = !quoted;
    else if (char === "," && !quoted) { row.push(value); value = ""; }
    else if ((char === "\n" || char === "\r") && !quoted) { if (char === "\r" && input[i + 1] === "\n") i++; row.push(value); rows.push(row); row = []; value = ""; }
    else value += char;
  }
  if (value || row.length) { row.push(value); rows.push(row); }
  return rows;
};

const data = JSON.parse(await readFile(path.join(root, "data/creative-data.json"), "utf8"));
if (data.length !== 20) fail(`Expected 20 data rows; found ${data.length}.`);
if (new Set(data.map((r) => r.id)).size !== 20) fail("Creative IDs must be unique.");
if (!data.some((r) => r.language === "English") || !data.some((r) => r.language === "Hindi") || !data.some((r) => r.language === "Marathi")) fail("English, Hindi, and Marathi rows are required.");
const csv = csvRows(await readFile(path.join(root, "data/creative-data.csv"), "utf8"));
if (csv.length !== 21) fail(`CSV must contain one header and 20 rows; found ${csv.length - 1} rows.`);
const header = csv[0];
for (const row of data) {
  const cells = csv.find((r) => r[0] === row.id);
  if (!cells) fail(`CSV is missing ${row.id}.`);
  for (const field of ["id", "product", "audience", "offer", "language", "headline", "locale", "art"]) {
    const csvField = field === "art" ? "image_asset" : field;
    if (cells[header.indexOf(csvField)] !== row[field]) fail(`CSV/JSON mismatch for ${row.id} ${field}.`);
  }
  if (/\d/.test([row.product, row.audience, row.offer, row.headline].join(" "))) fail(`${row.id} contains a numeric claim; figures must come from a row.`);
  const svgPath = path.join(root, "creatives", `${row.id}.svg`);
  const svg = await readFile(svgPath, "utf8");
  if (!svg.includes('width="1080" height="1080" viewBox="0 0 1080 1080"')) fail(`${row.id} canvas is not 1080 × 1080.`);
  if (!svg.includes(esc(row.headline)) || !svg.includes(esc(row.offer))) fail(`${row.id} does not contain its row headline and offer.`);
  if (!svg.includes(">SUTRANA</text>") || !svg.includes("MONEY FOR THE LIFE YOU’RE BUILDING")) fail(`${row.id} is missing the locked logo or brand line.`);
  const cta = row.locale === "hi" ? "विकल्प देखें" : row.locale === "mr" ? "पर्याय पाहा" : "Explore options";
  if (!svg.includes(esc(cta))) fail(`${row.id} is missing its fixed localized CTA.`);
  if (!svg.includes(`href="../assets/${row.art}"`)) fail(`${row.id} references the wrong image asset.`);
  await readFile(path.join(root, "assets", row.art));
  const disclaimer = row.locale === "hi" ? "केवल उदाहरण हेतु। पात्रता, नियम, शर्तें और उत्पाद-जोखिम लागू होते हैं। सभी दस्तावेज़ ध्यान से पढ़ें।" : row.locale === "mr" ? "फक्त उदाहरणासाठी. पात्रता, अटी, नियम आणि उत्पादनाशी संबंधित जोखीम लागू. सर्व कागदपत्रे काळजीपूर्वक वाचा." : "For illustration only. Eligibility, terms, conditions and product risks apply. Read all documents carefully.";
  if (!svg.includes(esc(disclaimer))) fail(`${row.id} is missing its fixed language-specific disclaimer.`);
  const palette = new Set(["#142B38", "#F5F0E6", "#F26B5B", "#A8B8A2"]);
  const colors = [...svg.matchAll(/#[0-9A-Fa-f]{6}/g)].map(([color]) => color.toUpperCase());
  if (colors.some((color) => !palette.has(color))) fail(`${row.id} uses a colour outside the locked palette.`);
  if (/guaranteed\s+(returns?|approval)|risk[- ]free\s+returns?/i.test(`${row.headline} ${row.offer}`)) fail(`${row.id} contains a prohibited claim.`);
}
const files = (await readdir(path.join(root, "creatives"))).filter((f) => f.endsWith(".svg"));
if (files.length !== 20) fail(`Expected 20 SVGs; found ${files.length}.`);
const master = await readFile(path.join(root, "template", "master-template.svg"), "utf8");
for (const label of ["LOCKED · LOGO", "LOCKED · COLOUR PALETTE", "SHEET · PRODUCT", "SHEET · LANGUAGE", "SHEET · OFFER", "AI · HEADLINE", "AI · IMAGE", "LOCKED · DISCLAIMER"]) if (!master.includes(label)) fail(`Annotated master is missing the ${label} label.`);
const qa = csvRows(await readFile(path.join(root, "qa-log.csv"), "utf8"));
if (qa.length !== 21) fail(`QA log must contain one header and 20 creative rows; found ${qa.length - 1}.`);
console.log("PASS: 20 rows match 20 SVGs; 1080 × 1080 dimensions, copy fields, image assets, CSV parity, and QA rows verified.");
console.log("REVIEW REQUIRED: visually inspect the gallery and have a native speaker verify the Hindi and Marathi copy before submission.");
