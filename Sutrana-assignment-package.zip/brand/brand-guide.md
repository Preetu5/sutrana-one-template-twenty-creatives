# Sutrana — brand guide

**Invented brand:** Sutrana (fictional personal-finance brand for this assignment). No affiliation with a real financial company is intended.

**What it offers:** personal and home loans, small-business loans, investments, and health insurance.

**Positioning:** a calm guide for practical money decisions. Help people explore choices; never pressure them to act.

## Visual identity

- **Ink navy** `#142B38` — primary type and structure.
- **Warm ivory** `#F5F0E6` — canvas and breathing room.
- **Coral** `#F26B5B` — accent and call to action.
- **Muted sage** `#A8B8A2` — secondary accent.
- **Headings:** Manrope ExtraBold (fallback: Arial).
- **Body:** Inter (fallback: Arial).
- **Hindi and Marathi:** Noto Sans Devanagari (fallback: Arial; verify glyph rendering on the target system).
- **Logo:** custom leaf-and-path symbol with the SUTRANA wordmark. Keep its shape and colours locked; do not redraw it with an image model.

## Voice

Warm, plain-spoken, steady, and non-judgmental. Use invitations such as “explore” and “compare.” Never promise approval, savings, returns, protection outcomes, or a fixed rate. Avoid urgency and fear.

## Template ownership

- **Locked:** logo, 1080 × 1080 canvas, layout, brand colours, type scale, CTA, disclaimer.
- **Data sheet:** product, audience, offer, and language. Use the row verbatim for the offer and locale.
- **AI-generated:** short headline and product-family illustration. The provided workflow uses four generated image assets and assigns one by product family. It does not generate, paraphrase, or calculate financial figures.
- **Review:** regional-language headlines, offers, and disclaimers are draft translations; a native speaker must approve them before publication.
